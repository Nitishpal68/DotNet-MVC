﻿namespace MVC_Application1.Controllers
{
    internal class TimeSheetViewModel
    {
        public object TimeSheetID { get; set; }
        public object EmployeeID { get; set; }
        public object Date { get; set; }
        public object ProjectID { get; set; }
        public object TaskID { get; set; }
        public object Description { get; set; }
        public object StartTime { get; set; }
        public object EndTime { get; set; }
    }
}